import requests, json
from bs4 import BeautifulSoup

books = []

for page in range(1, 6):
    url = f"http://books.toscrape.com/catalogue/page-{page}.html"
    soup = BeautifulSoup(requests.get(url).text, "html.parser")

    for b in soup.select("article.product_pod"):
        books.append({
            "title": b.h3.a["title"],
            "price": b.select_one(".price_color").text,
            "availability": b.select_one(".availability").text.strip()
        })

with open("books.json", "w", encoding="utf-8") as f:
    json.dump(books, f, ensure_ascii=False, indent=2)

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
import requests
from bs4 import BeautifulSoup

link = None

for page in range(1, 51):
    url = f"http://books.toscrape.com/catalogue/page-{page}.html"
    soup = BeautifulSoup(requests.get(url).text, "html.parser")

    for a in soup.select("h3 a"):
        if a["title"] == "Thirst":
            link = "http://books.toscrape.com/catalogue/" + a["href"].replace("../", "")
            break
    if link:
        break

if not link:
    print("Книга Thirst не найдена")
    exit()

options = Options()
options.add_argument("--headless")

driver = webdriver.Chrome(options=options)
driver.get(link)
driver.save_screenshot("thirst.png")
driver.quit() 